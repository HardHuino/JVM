package com.feteforraine;

public class Autotamponneuses {
    private final int id;
    private static int last_id=0;
    float x; // package-private pour ma classe de test
    float y; // package-private pour ma classe de test
    private boolean occupee;
    private String nomOccupant;
    private boolean allumee;
    private boolean clignotante;

    public Autotamponneuses() {

        /* Version sans appel du deuxieme constructeur :
        x = -1.0f;
        y = -1.0f;
        occupee = false;
        nomOccupant = NULL;
        allumee = false;
        clignotante = false;
         */

        // Version avec appel du deuxieme constructeur (plus concis) :
        this (-1.0f,-1.0f);
    }

    public Autotamponneuses(float coordX, float coordY) {
        id = last_id+1;
        x = coordX;
        y = coordY;
        occupee = false;
        nomOccupant = "";
        allumee = false;
        clignotante = false;
    }

    public boolean estOccupee() {
        return occupee;
    }

    public String getNomOccupant() {
        return nomOccupant;
    }

    public boolean estAllumee() {
        return allumee;
    }

    public boolean estClignotante() {
        return clignotante;
    }

    @Override public String toString() {
        return "[" + id + "] (" + x + "," + y + ")" + (estOccupee() ? " occupée " + "(" + nomOccupant + ") " : " libre") + (estAllumee() ? " allumée" : " éteinte") + (estClignotante() ? " clignotante" : " non clignotante");
    }

    public void place(float coordX, float coordY) {

    }

    public static void main(String[] args) {
        // TEST CONSTRUCTEURS
        Autotamponneuses constructeur1 = new Autotamponneuses();
        System.out.println("TEST CONSTRUCTEUR VIDE : " + (constructeur1.x == -1.0f && constructeur1.y == -1.0f ? "OK" : "FAIL"));
        Autotamponneuses constructeur2 = new Autotamponneuses(5.0f,6.2f);
        System.out.println("TEST CONSTRUCTEUR : " + (constructeur2.x == 5.0f && constructeur2.y == 6.2f ? "OK" : "FAIL"));

        // TEST METHODES
        System.out.println("TEST estOccupee : " + (constructeur1.estOccupee() ? "FAIL" : "OK"));
        System.out.println("TEST getNomOccupant : " + (constructeur1.getNomOccupant()=="" ? "OK" : "FAIL"));
        System.out.println("TEST estAllumee : " + (constructeur1.estAllumee() ? "FAIL" : "OK"));
        System.out.println("TEST estClignotante : " + (constructeur1.estClignotante() ? "FAIL" : "OK"));

        // TEST ID
        System.out.println("TEST id : " + (constructeur1.id == last_id+1 ? "OK" : "FAIL"));

        // TEST toString
        System.out.println(constructeur1.toString());
        //System.out.println("TEST toString : " + (constructeur1.toString() == "[1] (-1.0,-1.0) libre éteinte non clignotante" ? "OK" : "FAIL"));
    }
}